/**
 * HEAD COMPANY – Mama Dhia Trading (DhiaScent)
 * Backend Google Apps Script (percuma). Pasang dalam Google Sheet "Head Company DhiaScent – Database".
 *
 * Cara pasang (sekali sahaja):
 *  1. Buka sheet database > Extensions > Apps Script. Padam kod asal, tampal SEMUA kod ini. Save.
 *  2. Pilih fungsi "setup" > Run. Benarkan akses (Allow). Ini cipta tab yang perlu.
 *  3. Deploy > New deployment > jenis "Web app".
 *       Execute as: Me (dhiascenthq@gmail.com)   |   Who has access: Anyone
 *     Salin URL Web app (berakhir /exec) dan tampal dalam app > Tetapan > Sambungan.
 *  4. Bila kod ini dikemas kini: Deploy > Manage deployments > Edit > Version: New version > Deploy.
 *
 * Data live dibaca terus dari sheet sedia ada (tiada key-in berganda):
 *   Company Sales & Profit Dashboard (Sales, Ads), Expenses 2026 (Expense Log),
 *   Host Performance Tracker (Input), DhiaScent Task Monitoring (Log Harian, Projek, Adhoc, Live Founder).
 */

const SRC = {
  SALES: '1-9FMtkosDEPi38Pek1gI6Z0p2HKWBjA9_VHNB015XE4',   // Company Sales & Profit Dashboard
  EXPENSES: '11RBzcYJ2a0j19Oaqc1Etl5t0wQ0vGLuYSU0N6-_Yd-s', // Expenses 2026
  HOST: '1F8lXkLA0MjIPQwCoAMNhqwqWuuex3q94X00jXEaduB0',     // Host Performance Tracker - Oct 2026
  TASK: '1QvsCUIuROq1JSPAGIEacTqZIPeVGnCbkEudHx-bq5Ls'      // DhiaScent Task Monitoring
};

const TABLES = {
  Users:   ['id', 'nama', 'peranan', 'jabatanId', 'pin', 'aktif'],
  Jabatan: ['id', 'nama', 'pic', 'ikon', 'warna', 'tugas', 'urutan'],
  KPI:     ['id', 'jabatanId', 'nama', 'unit', 'sasaran', 'semasa', 'arah', 'sumber', 'kemaskini'],
  Laporan: ['id', 'jabatanId', 'tarikh', 'jenis', 'penulis', 'status', 'pencapaian', 'isu', 'rancangan', 'dibuat'],
  Komen:   ['id', 'laporanId', 'penulis', 'teks', 'dibuat'],
  Isu:     ['id', 'jabatanId', 'tajuk', 'tahap', 'status', 'pic', 'tarikh', 'tindakan', 'dibuat'],
  Pautan:  ['id', 'kategori', 'tajuk', 'url', 'nota', 'urutan'],
  Tetapan: ['id', 'nilai']
};
// Siapa boleh tulis: admin = semua. staf = jadual di bawah untuk jabatan sendiri. founder = Komen + Isu (arahan).
const STAF_TABLES = ['Laporan', 'Isu', 'KPI'];
const FOUNDER_TABLES = ['Komen', 'Isu'];

/* ====================== SETUP ====================== */
function setup() {
  const ss = SpreadsheetApp.getActive();
  Object.keys(TABLES).forEach(name => {
    let sh = ss.getSheetByName(name);
    if (!sh) sh = ss.insertSheet(name);
    const head = TABLES[name];
    const cur = sh.getRange(1, 1, 1, head.length).getValues()[0];
    if (cur.join('') === '') {
      sh.getRange(1, 1, 1, head.length).setValues([head]).setFontWeight('bold');
      sh.setFrozenRows(1);
    }
    sh.getRange('A:Z').setNumberFormat('@'); // simpan semua sebagai teks (tarikh tak bertukar)
  });
  const users = readTable_('Users');
  if (!users.length) {
    upsert_('Users', { id: 'u1', nama: 'Amira', peranan: 'admin', jabatanId: 'j2', pin: '1111', aktif: 'Ya' });
  }
  SpreadsheetApp.getUi && Logger.log('Setup siap. Tab: ' + Object.keys(TABLES).join(', '));
}

/* ====================== HTTP ====================== */
function doGet() {
  return json_({ ok: true, app: 'Head Company DhiaScent', masa: new Date().toISOString() });
}

function doPost(e) {
  let req = {};
  try { req = JSON.parse(e.postData.contents || '{}'); } catch (err) { return json_({ ok: false, error: 'Format permintaan salah' }); }
  try {
    const user = auth_(req.pin);
    if (!user) return json_({ ok: false, error: 'PIN salah atau akaun tidak aktif' });
    switch (req.action) {
      case 'login':
      case 'sync':
        return json_({ ok: true, user: safeUser_(user, true), data: allData_(user), live: live_(req.force) });
      case 'live':
        return json_({ ok: true, live: live_(true) });
      case 'upsert':
        checkWrite_(user, req.table, req.row);
        return json_({ ok: true, row: upsertLocked_(req.table, req.row, user) });
      case 'delete':
        checkWrite_(user, req.table, findRow_(req.table, req.id), true);
        return json_({ ok: true, deleted: deleteLocked_(req.table, req.id) });
      case 'projek':
        if (user.peranan !== 'admin') throw new Error('Hanya Head Admin boleh ubah projek');
        return json_({ ok: true, projek: saveProjek_(req.row) });
      case 'pin': {
        const baru = String(req.baru || '');
        if (!/^[0-9]{4,6}$/.test(baru)) throw new Error('PIN mesti 4–6 digit');
        upsertLocked_('Users', { id: user.id, pin: baru });
        return json_({ ok: true });
      }
      case 'tugas':
        return json_({ ok: true, tugas: setTugas_(user, req.row) });
      default:
        return json_({ ok: false, error: 'Tindakan tidak dikenali' });
    }
  } catch (err) {
    return json_({ ok: false, error: String(err.message || err) });
  }
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

/* ====================== AUTH ====================== */
function auth_(pin) {
  if (!pin) return null;
  pin = String(pin).trim();
  return readTable_('Users').find(u => String(u.pin).trim() === pin && String(u.aktif || 'Ya') !== 'Tidak') || null;
}
function safeUser_(u, keepPin) {
  const o = Object.assign({}, u);
  if (!keepPin) delete o.pin;
  return o;
}
function checkWrite_(user, table, row, isDelete) {
  if (!TABLES[table]) throw new Error('Jadual tidak wujud');
  if (user.peranan === 'admin') return;
  row = row || {};
  if (user.peranan === 'founder' && FOUNDER_TABLES.indexOf(table) >= 0) {
    if (table === 'Komen' && isDelete && row.penulis !== user.nama) throw new Error('Hanya boleh padam komen sendiri');
    return;
  }
  if (user.peranan === 'staf') {
    if (table === 'Komen') { if (isDelete && row.penulis !== user.nama) throw new Error('Hanya boleh padam komen sendiri'); return; }
    if (STAF_TABLES.indexOf(table) >= 0 && row.jabatanId && row.jabatanId === user.jabatanId) {
      const old = row.id ? findRow_(table, row.id) : null;
      if (!old || old.jabatanId === user.jabatanId) return;
    }
  }
  throw new Error('Anda tiada kebenaran untuk tindakan ini');
}

/* ====================== TABLE CRUD ====================== */
function sheet_(name) {
  const sh = SpreadsheetApp.getActive().getSheetByName(name);
  if (!sh) throw new Error('Tab "' + name + '" tiada. Jalankan setup() dahulu.');
  return sh;
}
function readTable_(name) {
  const sh = sheet_(name), head = TABLES[name];
  const n = sh.getLastRow() - 1;
  if (n < 1) return [];
  return sh.getRange(2, 1, n, head.length).getDisplayValues()
    .filter(r => r[0] !== '')
    .map(r => { const o = {}; head.forEach((h, i) => o[h] = r[i]); return o; });
}
function findRow_(name, id) { return readTable_(name).find(r => String(r.id) === String(id)); }

function allData_(user) {
  const out = {};
  Object.keys(TABLES).forEach(t => out[t] = readTable_(t));
  out.Users = out.Users.map(u => safeUser_(u, user.peranan === 'admin'));
  return out;
}

function upsertLocked_(name, row, user) {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try { return upsert_(name, row, user); } finally { lock.releaseLock(); }
}
function upsert_(name, row, user) {
  const sh = sheet_(name), head = TABLES[name];
  row = Object.assign({}, row);
  if (!row.id) row.id = name.charAt(0).toLowerCase() + Date.now().toString(36) + Math.floor(Math.random() * 1000);
  if (name === 'Users') {
    if (row.pin) {
      const clash = readTable_('Users').find(u => String(u.pin) === String(row.pin) && u.id !== row.id);
      if (clash) throw new Error('PIN ini sudah digunakan oleh ' + clash.nama);
    }
  }
  const ids = sh.getLastRow() > 1 ? sh.getRange(2, 1, sh.getLastRow() - 1, 1).getDisplayValues().map(r => r[0]) : [];
  const idx = ids.indexOf(String(row.id));
  if (idx >= 0) {
    const old = sh.getRange(idx + 2, 1, 1, head.length).getDisplayValues()[0];
    const vals = head.map((h, i) => (row[h] === undefined || (h === 'pin' && row[h] === '')) ? old[i] : String(row[h]));
    sh.getRange(idx + 2, 1, 1, head.length).setValues([vals]);
    const o = {}; head.forEach((h, i) => o[h] = vals[i]); return o;
  }
  const vals = head.map(h => row[h] === undefined ? '' : String(row[h]));
  sh.appendRow(vals);
  const o = {}; head.forEach((h, i) => o[h] = vals[i]); return o;
}
function deleteLocked_(name, id) {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const sh = sheet_(name);
    const ids = sh.getLastRow() > 1 ? sh.getRange(2, 1, sh.getLastRow() - 1, 1).getDisplayValues().map(r => r[0]) : [];
    const idx = ids.indexOf(String(id));
    if (idx < 0) return false;
    sh.deleteRow(idx + 2);
    if (name === 'Laporan') { // buang komen berkaitan
      const ks = sheet_('Komen');
      const kv = ks.getLastRow() > 1 ? ks.getRange(2, 1, ks.getLastRow() - 1, 2).getDisplayValues() : [];
      for (let i = kv.length - 1; i >= 0; i--) if (kv[i][1] === String(id)) ks.deleteRow(i + 2);
    }
    return true;
  } finally { lock.releaseLock(); }
}

/* ====================== PROJEK & TUGAS (tulis ke Task Monitoring) ====================== */
function saveProjek_(p) {
  const sh = SpreadsheetApp.openById(SRC.TASK).getSheetByName('Projek');
  const vals = [p.projek || '', p.pic || '', p.status || 'Sedang berjalan', p.progress || '', p.due || '', p.langkah || '', p.catatan || ''];
  let r = Number(p.r || 0);
  if (r >= 2) sh.getRange(r, 1, 1, 7).setValues([vals]);
  else { r = sh.getLastRow() + 1; sh.getRange(r, 1, 1, 7).setValues([vals]); }
  CacheService.getScriptCache().remove('live');
  return Object.assign({}, p, { r: r });
}
function setTugas_(user, t) {
  // t = {r, status}. Staf hanya boleh tanda tugasan sendiri.
  const sh = SpreadsheetApp.openById(SRC.TASK).getSheetByName('Log Harian');
  const r = Number(t.r);
  if (r < 2) throw new Error('Baris tidak sah');
  const pic = sh.getRange(r, 3).getDisplayValue();
  if (user.peranan === 'staf' && pic.toLowerCase().indexOf(user.nama.toLowerCase()) < 0) throw new Error('Hanya boleh tanda tugasan sendiri');
  if (user.peranan === 'founder') throw new Error('Founder hanya memantau');
  sh.getRange(r, 5).setValue(t.status);
  CacheService.getScriptCache().remove('live');
  return t;
}

/* ====================== DATA LIVE ====================== */
function live_(force) {
  const cache = CacheService.getScriptCache();
  if (!force) { const c = cache.get('live'); if (c) return JSON.parse(c); }
  const tz = Session.getScriptTimeZone() || 'Asia/Kuala_Lumpur';
  const now = new Date();
  const today = Utilities.formatDate(now, tz, 'yyyy-MM-dd');
  const cur = today.slice(0, 7);
  const out = { dijana: now.toISOString(), hariIni: today, bulan: cur, months: {}, daily: {}, hosts: [], tugas: null, projek: [], adhoc: [], founder: [], expCat: {}, ralat: [] };
  const M = k => (out.months[k] = out.months[k] || { sales: 0, items: 0, ads: 0, exp: 0, hari: 0, plat: {}, adsPlat: {} });
  const D = k => (out.daily[k] = out.daily[k] || { sales: 0, ads: 0, items: 0, tiktok: 0, shopee: 0, lain: 0 });

  // 1) Sales
  try {
    const sh = SpreadsheetApp.openById(SRC.SALES).getSheetByName('Sales');
    const v = sh.getRange(2, 1, Math.max(sh.getLastRow() - 1, 1), 10).getValues();
    const P = ['tiktok', 'shopee', 'meta', 'website', 'consignment', 'bizapp', 'fighter'];
    v.forEach(r => {
      const d = ymd_(r[0], tz); if (!d) return;
      const m = M(d.slice(0, 7));
      let tot = num_(r[9]);
      const parts = P.map((p, i) => num_(r[2 + i]));
      if (!tot) tot = parts.reduce((a, b) => a + b, 0);
      if (!tot && !num_(r[1])) return;
      m.sales += tot; m.items += num_(r[1]); m.hari++;
      P.forEach((p, i) => m.plat[p] = (m.plat[p] || 0) + parts[i]);
      if (d.slice(0, 7) === cur || d.slice(0, 7) === prevMonth_(cur)) {
        const x = D(d); x.sales += tot; x.items += num_(r[1]); x.tiktok += parts[0]; x.shopee += parts[1];
        x.lain += parts.slice(2).reduce((a, b) => a + b, 0);
      }
    });
  } catch (e) { out.ralat.push('Sales: ' + e.message); }

  // 2) Ads
  try {
    const sh = SpreadsheetApp.openById(SRC.SALES).getSheetByName('Ads');
    const v = sh.getRange(2, 1, Math.max(sh.getLastRow() - 1, 1), 6).getValues();
    const P = ['tiktok', 'shopee', 'meta', 'website'];
    v.forEach(r => {
      const d = ymd_(r[0], tz); if (!d) return;
      const m = M(d.slice(0, 7));
      const parts = P.map((p, i) => num_(r[1 + i]));
      const tot = num_(r[5]) || parts.reduce((a, b) => a + b, 0);
      m.ads += tot; P.forEach((p, i) => m.adsPlat[p] = (m.adsPlat[p] || 0) + parts[i]);
      if (d.slice(0, 7) === cur || d.slice(0, 7) === prevMonth_(cur)) D(d).ads += tot;
    });
  } catch (e) { out.ralat.push('Ads: ' + e.message); }

  // 3) Expenses 2026 – Expense Log (data dari baris 14: C tarikh, E kategori, J jumlah)
  try {
    const sh = SpreadsheetApp.openById(SRC.EXPENSES).getSheetByName('Expense Log');
    const last = sh.getLastRow();
    if (last >= 14) {
      const v = sh.getRange(14, 3, last - 13, 8).getValues(); // C..J
      v.forEach(r => {
        const d = ymd_(r[0], tz); if (!d) return;
        const amt = num_(r[7]); if (!amt) return;
        const mk = d.slice(0, 7);
        M(mk).exp += amt;
        if (mk === cur) { const c = String(r[2] || 'Lain-Lain').trim(); out.expCat[c] = (out.expCat[c] || 0) + amt; }
      });
    }
  } catch (e) { out.ralat.push('Expenses: ' + e.message); }

  // 4) Host live bulan semasa
  try {
    const sh = SpreadsheetApp.openById(SRC.HOST).getSheetByName('Input');
    const v = sh.getRange(2, 1, Math.max(sh.getLastRow() - 1, 1), 7).getValues();
    const H = {};
    v.forEach(r => {
      const nama = String(r[0] || '').trim(); if (!nama) return;
      const d = ymd_(r[1], tz); if (!d || d.slice(0, 7) !== cur) return;
      const h = H[nama] = H[nama] || { nama: nama, sesi: 0, jam: 0, sales: 0, cost: 0, sold: 0, target: 0, akhir: '' };
      h.sesi++; h.jam += num_(r[2]); h.sales += num_(r[3]); h.cost += num_(r[4]); h.sold += num_(r[5]); h.target += num_(r[6]);
      if (d > h.akhir) h.akhir = d;
    });
    out.hosts = Object.keys(H).map(k => H[k]).sort((a, b) => b.sales - a.sales);
  } catch (e) { out.ralat.push('Host: ' + e.message); }

  // 5) Task Monitoring
  try {
    const ss = SpreadsheetApp.openById(SRC.TASK);
    // Log Harian: tugasan hari ini + 7 hari
    const lh = ss.getSheetByName('Log Harian');
    const v = lh.getRange(2, 1, Math.max(lh.getLastRow() - 1, 1), 6).getValues();
    const from7 = Utilities.formatDate(new Date(now.getTime() - 6 * 864e5), tz, 'yyyy-MM-dd');
    const hari = [], minggu = {};
    v.forEach((r, i) => {
      const d = ymd_(r[0], tz); if (!d) return;
      const st = String(r[4] || 'Belum');
      if (d === today) hari.push({ r: i + 2, kategori: String(r[1]), pic: String(r[2]), tugas: String(r[3]), status: st, catatan: String(r[5] || '') });
      if (d >= from7 && d <= today && st !== 'Tak berkaitan') {
        const p = String(r[2]); minggu[p] = minggu[p] || { siap: 0, jumlah: 0 };
        minggu[p].jumlah++; if (st === 'Siap') minggu[p].siap++;
      }
    });
    out.tugas = { hari: hari, minggu: minggu };
    // Projek
    const pj = ss.getSheetByName('Projek');
    const pv = pj.getRange(2, 1, Math.max(pj.getLastRow() - 1, 1), 8).getDisplayValues();
    out.projek = pv.map((r, i) => ({ r: i + 2, projek: r[0], pic: r[1], status: r[2], progress: r[3], due: r[4], langkah: r[5], catatan: r[6], lewat: r[7] })).filter(p => p.projek);
    // Adhoc (belum siap)
    const ah = ss.getSheetByName('Adhoc');
    const av = ah.getRange(2, 1, Math.max(ah.getLastRow() - 1, 1), 9).getDisplayValues();
    out.adhoc = av.map(r => ({ ditambah: r[0], tugas: r[1], pic: r[2], due: r[3], keutamaan: r[4], status: r[5], siap: r[6], catatan: r[7], lewat: r[8] }))
      .filter(a => a.tugas && a.status !== 'Siap');
    // Live Founder bulan ini
    const lf = ss.getSheetByName('Live Founder');
    const fv = lf.getRange(2, 1, Math.max(lf.getLastRow() - 1, 1), 4).getValues();
    out.founder = fv.map(r => ({ tarikh: ymd_(r[0], tz), jam: num_(r[2]), catatan: String(r[3] || '') }))
      .filter(f => f.tarikh && f.tarikh.slice(0, 7) === cur && f.tarikh <= today && f.jam > 0);
  } catch (e) { out.ralat.push('Task Monitoring: ' + e.message); }

  // simpan hanya 13 bulan terakhir untuk ringkas
  const keys = Object.keys(out.months).sort();
  keys.slice(0, Math.max(0, keys.length - 13)).forEach(k => delete out.months[k]);
  try { cache.put('live', JSON.stringify(out), 300); } catch (e) {}
  return out;
}

/* ====================== HELPERS ====================== */
function num_(v) {
  if (typeof v === 'number') return isFinite(v) ? v : 0;
  if (v === null || v === undefined) return 0;
  const n = Number(String(v).replace(/RM/gi, '').replace(/[^0-9.\-]/g, ''));
  return isFinite(n) ? n : 0;
}
const MON_ = { jan: 1, feb: 2, mar: 3, mac: 3, apr: 4, may: 5, mei: 5, jun: 6, jul: 7, aug: 8, ogo: 8, sep: 9, oct: 10, okt: 10, nov: 11, dec: 12, dis: 12 };
function ymd_(v, tz) {
  if (!v) return '';
  if (Object.prototype.toString.call(v) === '[object Date]') return isNaN(v) ? '' : Utilities.formatDate(v, tz, 'yyyy-MM-dd');
  const s = String(v).trim();
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) return m[1] + '-' + pad_(m[2]) + '-' + pad_(m[3]);
  m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/); // M/D/YYYY (format sheet host)
  if (m) return m[3] + '-' + pad_(m[1]) + '-' + pad_(m[2]);
  m = s.match(/^(\d{1,2})[-\s]([A-Za-z]{3})[A-Za-z]*[-\s](\d{4})/); // 3-Jan-2026
  if (m && MON_[m[2].toLowerCase()]) return m[3] + '-' + pad_(MON_[m[2].toLowerCase()]) + '-' + pad_(m[1]);
  return '';
}
function pad_(n) { n = String(n); return n.length < 2 ? '0' + n : n; }
function prevMonth_(ym) {
  let y = Number(ym.slice(0, 4)), m = Number(ym.slice(5, 7)) - 1;
  if (m < 1) { m = 12; y--; }
  return y + '-' + pad_(m);
}

/** Uji dari editor: Run > testLive, kemudian lihat Execution log. */
function testLive() { Logger.log(JSON.stringify(live_(true)).slice(0, 4000)); }
