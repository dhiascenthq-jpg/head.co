# Head Company · DhiaScent — Panduan Setup (kos RM0)

Ada 3 bahagian yang semuanya percuma. Masa yang diperlukan lebih kurang 15 minit, dan setup ni dibuat sekali sahaja.

| Bahagian | Di mana | Fungsi |
|---|---|---|
| Database | Google Sheet **Head Company DhiaScent – Database** (sudah dicipta dalam Drive dhiascenthq@gmail.com) | Simpan jabatan, KPI, laporan, isu, pautan dan pengguna |
| Backend | Apps Script dalam sheet di atas (fail `Code.gs`) | Baca data live dari Sales Dashboard, Expenses 2026, Host Tracker dan Task Monitoring |
| App (web + phone) | GitHub Pages (fail `index.html`, `manifest.json`, `sw.js`, folder `icons`) | Paparan untuk Founder, Head Admin dan staf. Boleh di-install di phone |

---

## Langkah 1: Pasang backend (5 minit)
1. Buka Google Sheet **Head Company DhiaScent – Database**.
2. Pilih menu **Extensions › Apps Script**. Padam semua kod yang ada, kemudian tampal **semua** isi `Code.gs`. Tekan **Save**.
3. Di atas, pilih fungsi **setup** dan tekan **Run**. Bila diminta, klik **Review permissions**, pilih akaun dhiascenthq, kemudian **Advanced › Go to project › Allow**.
4. (Pilihan) Pilih fungsi **testLive** dan tekan **Run**. Dalam *Execution log* sepatutnya keluar data sales bulan ini.
5. Klik **Deploy › New deployment** dan pilih jenis **Web app**.
   - Execute as: **Me**
   - Who has access: **Anyone**
6. Klik **Deploy**, kemudian **salin URL** yang berakhir dengan `/exec`.

## Langkah 2: Letak app di internet (5 minit, GitHub Pages)
1. Daftar akaun percuma di github.com (boleh guna emel syarikat).
2. Klik **New repository** dan namakan `headco`. Pilih **Public**, kemudian klik **Create**.
3. Klik **uploading an existing file**. Seret semua fail dari folder zip (`index.html`, `manifest.json`, `sw.js` dan folder `icons`), kemudian klik **Commit changes**.
4. Pergi ke **Settings › Pages**. Pada Source pilih **Deploy from a branch**, Branch **main** / **(root)**, kemudian klik **Save**.
5. Selepas 1–2 minit, link app akan siap: `https://NAMA-AKAUN.github.io/headco/`

> Cara lain tanpa GitHub: app.netlify.com/drop. Seret folder tu ke sana dan daftar akaun percuma supaya link kekal.

## Langkah 3: Sambungkan app ke Google Sheet
1. Buka link app dan log masuk dengan PIN Head Admin (**1111**).
2. Pergi ke **Tetapan › Sambungan Google Sheet**. Tampal URL `/exec` tadi, kemudian klik **Simpan & sambung**.
3. Supaya Dato' dan staf tak perlu tampal URL sendiri: buka `index.html` di GitHub (ikon pensel), tukar baris
   `const DEFAULT_API = '';` kepada `const DEFAULT_API = 'URL_EXEC_ANDA';`, kemudian klik **Commit**.

## Langkah 4: Tukar PIN (WAJIB)
PIN awal yang disediakan: Amira 1111 · Dato' Belly 2222 · Datin Farrah 3333 · Ayuni 4444 · Nur Iman 5555 · Zulima 6666.
Pergi ke **Tetapan › Pengguna & PIN** dan tukar semua PIN tu sebelum link dikongsi. Setiap orang juga boleh tukar PIN sendiri di Tetapan › Akaun saya.

## Langkah 5: Install di phone
- **Android (Chrome):** buka link, tekan menu ⋮ dan pilih **Install app**.
- **iPhone (Safari):** buka link, tekan butang Kongsi ⬆︎ dan pilih **Add to Home Screen**.

---

## Siapa boleh buat apa
| Peranan | Boleh |
|---|---|
| Head Admin | Semua: jabatan, KPI, projek, pengguna, sasaran, pautan |
| Founder | Lihat semua, komen pada laporan, tambah arahan/isu |
| Staf | Hantar laporan, isu dan KPI untuk jabatan sendiri, serta tanda tugasan harian sendiri |

## Dari mana data datang (tiada key-in berganda)
- **Sales & ROI:** Company Sales & Profit Dashboard (tab Sales, Ads)
- **Perbelanjaan:** Expenses 2026 › Expense Log (baris 14 ke bawah, lajur C, E dan J)
- **Host:** Host Performance Tracker › Input (bulan semasa)
- **Tugasan, projek, adhoc, Live Founder:** DhiaScent Task Monitoring
- Data live disimpan dalam cache selama 5 minit. Tekan butang ⟳ dalam app untuk tarik data terkini.

## Bila kod dikemas kini
Apps Script: **Deploy › Manage deployments › ✏️ › Version: New version › Deploy**. URL kekal sama.
App: upload `index.html` baharu ke GitHub. Phone akan dapat versi baharu bila app dibuka semula.

## Nota
- Bulan baharu: kalau Host Performance Tracker ditukar kepada fail baru (cth "Nov 2026"), kemas kini ID `HOST` di bahagian atas `Code.gs`.
- KPI bertanda **Auto** dikira sendiri. KPI **Manual** dikemas kini oleh PIC jabatan.
- Angka sales − perbelanjaan ialah anggaran kasar sahaja, sebab expense Jan–Mei belum lengkap.
